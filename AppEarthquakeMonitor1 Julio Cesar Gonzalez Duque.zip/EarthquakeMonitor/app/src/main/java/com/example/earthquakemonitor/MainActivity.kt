package com.example.earthquakemonitor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.earthquakemonitor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //recycler usando listas para usarlas con los datos agregados
        binding.eqRecycler.layoutManager = LinearLayoutManager(this)
        val eqList = mutableListOf<Earthquake>()
        eqList.add(Earthquake("1","Lerdo", 6.1, 232434L, -123213.23213, 28.23123))
        eqList.add(Earthquake("2","Gómez Palacio", 8.6, 23432434L, -123213.23213, 28.23123))
        eqList.add(Earthquake("3","Durango", 9.5, 25434L, -123213.23213, 28.23123))
        eqList.add(Earthquake("4","Monterrey", 1.9, 67234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("5","París", 7.8, 28765234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("6","Chihuahua", 5.8, 7867234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("7","Acapulco", 3.8, 6745234L, -123213.23213, 28.23123))
        //adapter para mandar los datos
        val adapter = EqAdapter()
        binding.eqRecycler.adapter = adapter
        adapter.submitList(eqList)
        adapter.onItemClickListener = {
            Toast.makeText(this, it.place, Toast.LENGTH_SHORT).show()
        }
        //condición para mostrar una advertencia si no hay datos
        if (eqList.isEmpty()) {
            binding.eqEmptyView.visibility = View.VISIBLE
        } else {
            binding.eqEmptyView.visibility = View.GONE
        }
    }
}